package com.example.entity;

public enum TxnType {

		CREDIT, DEBIT
	
}
